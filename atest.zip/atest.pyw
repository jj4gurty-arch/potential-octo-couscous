import tkinter as tk
import random
import math
import time

# =========================
# CONFIG
# =========================

START_POPUPS = 15
MAX_POPUPS = 60

WIDTH = 360
HEIGHT = 200

BG_COLORS = [
    "#000000",
    "#050505",
    "#100010",
    "#001122",
    "#220000"
]

TEXT_COLORS = [
    "#00ff99",
    "#00ffff",
    "#ff00ff",
    "#ffff00",
    "#ff4444",
    "#ffffff",
]

MESSAGES = [
    "SYSTEM COMPROMISED",
    "DOWNLOADING MEMES...",
    "STEALING HOMEWORK...",
    "ACCESSING SNACK FILES",
    "ENABLING RGB MODE",
    "CONNECTING TO NASA...",
    "VIRUS.EXE HAS FEELINGS",
    "SUMMONING POPUPS...",
]

TERMINAL_LINES = [
    "injecting chaos...",
    "finding cookies...",
    "activating gamer mode...",
    "loading fake malware...",
    "decrypting memes...",
    "boosting FPS...",
    "bypassing homework...",
    "downloading more RAM...",
]

# =========================
# GLOBALS
# =========================

windows = []
running = True
popup_counter = 0

# =========================
# ROOT
# =========================

root = tk.Tk()
root.withdraw()

# =========================
# FUNCTIONS
# =========================

def random_color():
    return random.choice(TEXT_COLORS)

def random_bg():
    return random.choice(BG_COLORS)

def close_all(event=None):
    global running

    running = False

    for popup in windows:
        try:
            popup.destroy()
        except:
            pass

    root.destroy()

def beep():
    try:
        root.bell()
    except:
        pass

def matrix_text():
    chars = "01ABCDEF#$%&"
    return "".join(random.choice(chars) for _ in range(40))

def spawn_popup(event=None):
    if len(windows) < MAX_POPUPS:
        create_popup()

def auto_spawn():

    if not running:
        return

    if random.randint(1, 4) == 1:
        if len(windows) < MAX_POPUPS:
            create_popup()

    root.after(1200, auto_spawn)

# =========================
# POPUP CLASS
# =========================

class VirusPopup:

    def __init__(self):

        global popup_counter

        popup_counter += 1

        self.win = tk.Toplevel(root)

        self.win.title(f"Virus Popup #{popup_counter}")

        self.width = WIDTH
        self.height = HEIGHT

        sw = self.win.winfo_screenwidth()
        sh = self.win.winfo_screenheight()

        self.x = random.randint(0, sw - WIDTH)
        self.y = random.randint(0, sh - HEIGHT)

        self.dx = random.choice([-8, -7, -6, 6, 7, 8])
        self.dy = random.choice([-8, -7, -6, 6, 7, 8])

        self.angle = random.random() * math.pi * 2

        self.win.geometry(f"{WIDTH}x{HEIGHT}+{self.x}+{self.y}")
        self.win.configure(bg="black")

        # Always on top
        self.win.attributes("-topmost", True)

        # =========================
        # TITLE
        # =========================

        self.title = tk.Label(
            self.win,
            text=random.choice(MESSAGES),
            fg=random_color(),
            bg="black",
            font=("Arial", 15, "bold")
        )
        self.title.pack(pady=8)

        # =========================
        # TERMINAL
        # =========================

        self.terminal = tk.Label(
            self.win,
            text=random.choice(TERMINAL_LINES),
            fg="#00ff66",
            bg="black",
            font=("Consolas", 10)
        )
        self.terminal.pack()

        # Matrix spam
        self.matrix = tk.Label(
            self.win,
            text=matrix_text(),
            fg="#00aa44",
            bg="black",
            font=("Consolas", 8)
        )
        self.matrix.pack(pady=5)

        # =========================
        # COUNTER
        # =========================

        self.counter = tk.Label(
            self.win,
            text=f"POPUPS: {len(windows)}",
            fg="cyan",
            bg="black",
            font=("Arial", 10, "bold")
        )
        self.counter.pack()

        # =========================
        # CONTROLS
        # =========================

        self.controls = tk.Label(
            self.win,
            text="S = Spawn | X/Q/ESC = Quit",
            fg="white",
            bg="black",
            font=("Arial", 9)
        )
        self.controls.pack(side="bottom", pady=6)

        # =========================
        # KEYBINDS
        # =========================

        # Quit controls
        self.win.bind("<Escape>", close_all)

        self.win.bind("<x>", close_all)
        self.win.bind("<X>", close_all)

        self.win.bind("<q>", close_all)
        self.win.bind("<Q>", close_all)

        # Spawn controls
        self.win.bind("<s>", spawn_popup)
        self.win.bind("<S>", spawn_popup)

        windows.append(self.win)

        self.animate()

    # =========================
    # ANIMATION
    # =========================

    def animate(self):

        if not running:
            return

        sw = self.win.winfo_screenwidth()
        sh = self.win.winfo_screenheight()

        # Movement
        self.x += self.dx
        self.y += self.dy

        # Bounce
        if self.x <= 0 or self.x + self.width >= sw:
            self.dx *= -1
            beep()

        if self.y <= 0 or self.y + self.height >= sh:
            self.dy *= -1
            beep()

        # Pulse animation
        pulse = int(math.sin(time.time() * 6 + self.angle) * 8)

        w = WIDTH + pulse
        h = HEIGHT + pulse

        self.win.geometry(f"{w}x{h}+{self.x}+{self.y}")

        # Update text/colors
        self.title.config(
            text=random.choice(MESSAGES),
            fg=random_color()
        )

        self.terminal.config(
            text=random.choice(TERMINAL_LINES),
            fg=random_color()
        )

        self.matrix.config(
            text=matrix_text()
        )

        self.counter.config(
            text=f"POPUPS: {len(windows)}",
            fg=random_color()
        )

        # Flash background
        bg = random_bg()

        self.win.configure(bg=bg)

        for widget in self.win.winfo_children():
            widget.configure(bg=bg)

        # Random shake
        if random.randint(1, 8) == 1:
            self.x += random.randint(-8, 8)
            self.y += random.randint(-8, 8)

        # Transparency flicker
        try:
            alpha = random.uniform(0.85, 1.0)
            self.win.attributes("-alpha", alpha)
        except:
            pass

        # Continue animation
        self.win.after(33, self.animate)

# =========================
# CREATE POPUPS
# =========================

def create_popup():
    VirusPopup()

for _ in range(START_POPUPS):
    create_popup()

auto_spawn()

root.mainloop()
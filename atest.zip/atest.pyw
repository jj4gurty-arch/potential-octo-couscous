import tkinter as tk
import random
import time

windows = []
running = True
popup_count = 0

messages = [
    "SYSTEM COMPROMISED 😱",
    "Downloading memes...",
    "Accessing snack files 🍕",
    "Virus.exe has feelings",
    "Stealing homework...",
    "Totally harmless 😎",
    "Connecting to NASA...",
    "Installing more popups...",
]

terminal_lines = [
    "injecting chaos...",
    "finding cookies...",
    "activating gamer mode...",
    "loading fake malware...",
    "boosting RGB...",
]

colors = [
    "lime",
    "cyan",
    "yellow",
    "orange",
    "red",
    "magenta",
    "white",
]

def close_all(event=None):
    global running
    running = False

    for win in windows:
        try:
            win.destroy()
        except:
            pass

def screen_shake(win):
    if not running:
        return

    x = win.winfo_x()
    y = win.winfo_y()

    shake_x = random.randint(-4, 4)
    shake_y = random.randint(-4, 4)

    win.geometry(f"+{x + shake_x}+{y + shake_y}")

def animate(win, label, terminal, counter, dx, dy):
    if not running:
        return

    x = win.winfo_x()
    y = win.winfo_y()

    sw = win.winfo_screenwidth()
    sh = win.winfo_screenheight()

    width = 340
    height = 180

    x += dx
    y += dy

    # Bounce
    if x <= 0 or x + width >= sw:
        dx = -dx

    if y <= 0 or y + height >= sh:
        dy = -dy

    x += dx
    y += dy

    win.geometry(f"{width}x{height}+{x}+{y}")

    # Random visuals
    label.config(
        text=random.choice(messages),
        fg=random.choice(colors)
    )

    terminal.config(
        text=random.choice(terminal_lines),
        fg=random.choice(colors)
    )

    counter.config(
        text=f"POPUPS: {len(windows)}",
        fg=random.choice(colors)
    )

    # Flash background
    bg = random.choice(["black", "gray10", "darkred", "darkblue"])
    win.configure(bg=bg)

    for widget in win.winfo_children():
        try:
            widget.configure(bg=bg)
        except:
            pass

    # Tiny shake effect
    if random.randint(1, 5) == 1:
        screen_shake(win)

    win.after(70, lambda: animate(win, label, terminal, counter, dx, dy))

def spawn_popup(event=None):
    create_popup()

def create_popup():
    global popup_count

    popup_count += 1

    win = tk.Tk()
    win.title(f"Virus Popup #{popup_count}")

    width = 340
    height = 180

    x = random.randint(0, 1000)
    y = random.randint(0, 600)

    win.geometry(f"{width}x{height}+{x}+{y}")
    win.configure(bg="black")

    title = tk.Label(
        win,
        text=random.choice(messages),
        fg=random.choice(colors),
        bg="black",
        font=("Arial", 14, "bold")
    )
    title.pack(pady=8)

    terminal = tk.Label(
        win,
        text=random.choice(terminal_lines),
        fg="lime",
        bg="black",
        font=("Consolas", 10)
    )
    terminal.pack()

    counter = tk.Label(
        win,
        text=f"POPUPS: {len(windows)}",
        fg="cyan",
        bg="black",
        font=("Arial", 10, "bold")
    )
    counter.pack(pady=5)

    controls = tk.Label(
        win,
        text="S = Spawn More   |   X/Q = Quit",
        fg="white",
        bg="black",
        font=("Arial", 9)
    )
    controls.pack(side="bottom", pady=6)

    # Keybinds
    win.bind("<KeyPress-x>", close_all)
    win.bind("<KeyPress-X>", close_all)

    win.bind("<KeyPress-q>", close_all)
    win.bind("<KeyPress-Q>", close_all)

    win.bind("<KeyPress-s>", spawn_popup)
    win.bind("<KeyPress-S>", spawn_popup)

    windows.append(win)

    dx = random.choice([-7, -6, -5, 5, 6, 7])
    dy = random.choice([-7, -6, -5, 5, 6, 7])

    animate(win, title, terminal, counter, dx, dy)

# Start with 20 popups
for i in range(20):
    create_popup()

tk.mainloop()